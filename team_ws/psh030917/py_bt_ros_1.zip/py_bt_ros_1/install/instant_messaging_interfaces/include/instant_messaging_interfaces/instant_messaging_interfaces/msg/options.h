// generated from rosidl_generator_c/resource/idl.h.em
// with input from instant_messaging_interfaces:msg/Options.idl
// generated code does not contain a copyright notice

#ifndef INSTANT_MESSAGING_INTERFACES__MSG__OPTIONS_H_
#define INSTANT_MESSAGING_INTERFACES__MSG__OPTIONS_H_

#include "instant_messaging_interfaces/msg/detail/options__struct.h"
#include "instant_messaging_interfaces/msg/detail/options__functions.h"
#include "instant_messaging_interfaces/msg/detail/options__type_support.h"

#endif  // INSTANT_MESSAGING_INTERFACES__MSG__OPTIONS_H_
