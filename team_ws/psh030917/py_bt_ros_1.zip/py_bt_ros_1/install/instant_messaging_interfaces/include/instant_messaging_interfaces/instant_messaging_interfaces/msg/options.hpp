// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef INSTANT_MESSAGING_INTERFACES__MSG__OPTIONS_HPP_
#define INSTANT_MESSAGING_INTERFACES__MSG__OPTIONS_HPP_

#include "instant_messaging_interfaces/msg/detail/options__struct.hpp"
#include "instant_messaging_interfaces/msg/detail/options__builder.hpp"
#include "instant_messaging_interfaces/msg/detail/options__traits.hpp"
#include "instant_messaging_interfaces/msg/detail/options__type_support.hpp"

#endif  // INSTANT_MESSAGING_INTERFACES__MSG__OPTIONS_HPP_
