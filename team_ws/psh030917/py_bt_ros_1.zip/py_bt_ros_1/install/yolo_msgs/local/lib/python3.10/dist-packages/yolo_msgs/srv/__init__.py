from yolo_msgs.srv._set_classes import SetClasses  # noqa: F401
