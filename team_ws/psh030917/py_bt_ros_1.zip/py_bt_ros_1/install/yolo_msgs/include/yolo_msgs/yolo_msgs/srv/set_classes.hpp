// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef YOLO_MSGS__SRV__SET_CLASSES_HPP_
#define YOLO_MSGS__SRV__SET_CLASSES_HPP_

#include "yolo_msgs/srv/detail/set_classes__struct.hpp"
#include "yolo_msgs/srv/detail/set_classes__builder.hpp"
#include "yolo_msgs/srv/detail/set_classes__traits.hpp"
#include "yolo_msgs/srv/detail/set_classes__type_support.hpp"

#endif  // YOLO_MSGS__SRV__SET_CLASSES_HPP_
