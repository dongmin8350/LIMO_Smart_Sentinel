// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef YOLO_MSGS__MSG__VECTOR2_HPP_
#define YOLO_MSGS__MSG__VECTOR2_HPP_

#include "yolo_msgs/msg/detail/vector2__struct.hpp"
#include "yolo_msgs/msg/detail/vector2__builder.hpp"
#include "yolo_msgs/msg/detail/vector2__traits.hpp"
#include "yolo_msgs/msg/detail/vector2__type_support.hpp"

#endif  // YOLO_MSGS__MSG__VECTOR2_HPP_
