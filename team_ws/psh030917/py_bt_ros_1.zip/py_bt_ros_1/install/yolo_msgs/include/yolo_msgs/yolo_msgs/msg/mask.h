// generated from rosidl_generator_c/resource/idl.h.em
// with input from yolo_msgs:msg/Mask.idl
// generated code does not contain a copyright notice

#ifndef YOLO_MSGS__MSG__MASK_H_
#define YOLO_MSGS__MSG__MASK_H_

#include "yolo_msgs/msg/detail/mask__struct.h"
#include "yolo_msgs/msg/detail/mask__functions.h"
#include "yolo_msgs/msg/detail/mask__type_support.h"

#endif  // YOLO_MSGS__MSG__MASK_H_
