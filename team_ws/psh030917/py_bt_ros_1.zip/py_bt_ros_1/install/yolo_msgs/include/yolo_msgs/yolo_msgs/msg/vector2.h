// generated from rosidl_generator_c/resource/idl.h.em
// with input from yolo_msgs:msg/Vector2.idl
// generated code does not contain a copyright notice

#ifndef YOLO_MSGS__MSG__VECTOR2_H_
#define YOLO_MSGS__MSG__VECTOR2_H_

#include "yolo_msgs/msg/detail/vector2__struct.h"
#include "yolo_msgs/msg/detail/vector2__functions.h"
#include "yolo_msgs/msg/detail/vector2__type_support.h"

#endif  // YOLO_MSGS__MSG__VECTOR2_H_
