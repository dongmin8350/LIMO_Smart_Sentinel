// generated from rosidl_generator_c/resource/idl.h.em
// with input from yolo_msgs:msg/Pose2D.idl
// generated code does not contain a copyright notice

#ifndef YOLO_MSGS__MSG__POSE2_D_H_
#define YOLO_MSGS__MSG__POSE2_D_H_

#include "yolo_msgs/msg/detail/pose2_d__struct.h"
#include "yolo_msgs/msg/detail/pose2_d__functions.h"
#include "yolo_msgs/msg/detail/pose2_d__type_support.h"

#endif  // YOLO_MSGS__MSG__POSE2_D_H_
