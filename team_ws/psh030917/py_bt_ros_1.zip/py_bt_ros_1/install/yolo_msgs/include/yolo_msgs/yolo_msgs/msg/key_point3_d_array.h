// generated from rosidl_generator_c/resource/idl.h.em
// with input from yolo_msgs:msg/KeyPoint3DArray.idl
// generated code does not contain a copyright notice

#ifndef YOLO_MSGS__MSG__KEY_POINT3_D_ARRAY_H_
#define YOLO_MSGS__MSG__KEY_POINT3_D_ARRAY_H_

#include "yolo_msgs/msg/detail/key_point3_d_array__struct.h"
#include "yolo_msgs/msg/detail/key_point3_d_array__functions.h"
#include "yolo_msgs/msg/detail/key_point3_d_array__type_support.h"

#endif  // YOLO_MSGS__MSG__KEY_POINT3_D_ARRAY_H_
