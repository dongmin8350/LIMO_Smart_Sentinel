// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef YOLO_MSGS__MSG__POINT2_D_HPP_
#define YOLO_MSGS__MSG__POINT2_D_HPP_

#include "yolo_msgs/msg/detail/point2_d__struct.hpp"
#include "yolo_msgs/msg/detail/point2_d__builder.hpp"
#include "yolo_msgs/msg/detail/point2_d__traits.hpp"
#include "yolo_msgs/msg/detail/point2_d__type_support.hpp"

#endif  // YOLO_MSGS__MSG__POINT2_D_HPP_
