// generated from rosidl_generator_c/resource/idl.h.em
// with input from yolo_msgs:msg/KeyPoint3D.idl
// generated code does not contain a copyright notice

#ifndef YOLO_MSGS__MSG__KEY_POINT3_D_H_
#define YOLO_MSGS__MSG__KEY_POINT3_D_H_

#include "yolo_msgs/msg/detail/key_point3_d__struct.h"
#include "yolo_msgs/msg/detail/key_point3_d__functions.h"
#include "yolo_msgs/msg/detail/key_point3_d__type_support.h"

#endif  // YOLO_MSGS__MSG__KEY_POINT3_D_H_
