// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef YOLO_MSGS__MSG__KEY_POINT2_D_ARRAY_HPP_
#define YOLO_MSGS__MSG__KEY_POINT2_D_ARRAY_HPP_

#include "yolo_msgs/msg/detail/key_point2_d_array__struct.hpp"
#include "yolo_msgs/msg/detail/key_point2_d_array__builder.hpp"
#include "yolo_msgs/msg/detail/key_point2_d_array__traits.hpp"
#include "yolo_msgs/msg/detail/key_point2_d_array__type_support.hpp"

#endif  // YOLO_MSGS__MSG__KEY_POINT2_D_ARRAY_HPP_
