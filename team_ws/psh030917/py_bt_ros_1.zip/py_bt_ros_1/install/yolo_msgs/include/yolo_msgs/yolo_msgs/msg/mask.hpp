// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef YOLO_MSGS__MSG__MASK_HPP_
#define YOLO_MSGS__MSG__MASK_HPP_

#include "yolo_msgs/msg/detail/mask__struct.hpp"
#include "yolo_msgs/msg/detail/mask__builder.hpp"
#include "yolo_msgs/msg/detail/mask__traits.hpp"
#include "yolo_msgs/msg/detail/mask__type_support.hpp"

#endif  // YOLO_MSGS__MSG__MASK_HPP_
