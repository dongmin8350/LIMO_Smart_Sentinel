// generated from rosidl_generator_c/resource/idl.h.em
// with input from yolo_msgs:srv/SetClasses.idl
// generated code does not contain a copyright notice

#ifndef YOLO_MSGS__SRV__SET_CLASSES_H_
#define YOLO_MSGS__SRV__SET_CLASSES_H_

#include "yolo_msgs/srv/detail/set_classes__struct.h"
#include "yolo_msgs/srv/detail/set_classes__functions.h"
#include "yolo_msgs/srv/detail/set_classes__type_support.h"

#endif  // YOLO_MSGS__SRV__SET_CLASSES_H_
