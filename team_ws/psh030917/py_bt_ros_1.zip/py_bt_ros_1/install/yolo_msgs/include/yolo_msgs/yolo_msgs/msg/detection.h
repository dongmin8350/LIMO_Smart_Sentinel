// generated from rosidl_generator_c/resource/idl.h.em
// with input from yolo_msgs:msg/Detection.idl
// generated code does not contain a copyright notice

#ifndef YOLO_MSGS__MSG__DETECTION_H_
#define YOLO_MSGS__MSG__DETECTION_H_

#include "yolo_msgs/msg/detail/detection__struct.h"
#include "yolo_msgs/msg/detail/detection__functions.h"
#include "yolo_msgs/msg/detail/detection__type_support.h"

#endif  // YOLO_MSGS__MSG__DETECTION_H_
